package project;

public class mainDriver {

	public static void main(String[] args) {

		B_UI obj = new B_UI();
		obj.setUplabels();
		obj.setUpgrid();
		

	}

}
